﻿namespace TelegramNoteBot
{
    public enum UserState
    {
        Command,
        AddNote,
        DeleteNote
    }
}
